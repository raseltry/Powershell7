# Docker

Dockerfiles to build the Docker images for PowerShell Core have been moved to [PowerShell/PowerShell-Docker](https://github.com/PowerShell/PowerShell-Docker).
