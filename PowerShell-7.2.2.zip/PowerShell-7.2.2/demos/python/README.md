# PowerShell/Python Interoperation Demo

The `demo_script.ps1` file in this directory walks through a
demonstration of basic interoperation between PowerShell and Python
including how to use JSON to exchange structured objects between
Python and PowerShell.

The other files in this directory are referenced by `demo_script.ps1`.
